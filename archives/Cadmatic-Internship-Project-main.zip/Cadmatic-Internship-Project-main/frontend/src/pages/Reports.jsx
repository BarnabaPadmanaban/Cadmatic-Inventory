import React, { useState, useEffect } from 'react';
import toast from 'react-hot-toast';
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  LineChart, Line, PieChart, Pie, Cell, Legend
} from 'recharts';
import Topbar from '../components/Topbar';
import { equipmentAPI } from '../services/api';
import { STATUS_MAP } from '../utils/statusUtils';

export default function Reports() {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    equipmentAPI.getDashboard()
      .then(res => setData(res.data.data))
      .catch(() => toast.error('Failed to load report data'))
      .finally(() => setLoading(false));
  }, []);

  if (loading) return (
    <>
      <Topbar title="Reports" subtitle="Analytics & Insights" onRefresh={() => {}} />
      <div className="page-content"><div className="page-loader"><div className="loading-spinner" /></div></div>
    </>
  );

  const statusData = (data?.statusBreakdown || []).map(s => ({
    name: s.status_name.split(' ').slice(0, 2).join(' '),
    fullName: s.status_name,
    count: s.count,
    color: s.status_color,
    pct: data?.stats?.total_equipment ? ((s.count / data.stats.total_equipment) * 100).toFixed(1) : 0
  }));

  const stats = data?.stats || {};

  const completionRate = stats.total_equipment
    ? Math.round(((stats.commissioned + stats.handover_om) / stats.total_equipment) * 100)
    : 0;

  return (
    <>
      <Topbar title="Reports & Analytics" subtitle="Equipment status insights" onRefresh={() => {}} />
      <div className="page-content">

        {/* KPI Row */}
        <div className="stats-grid mb-6">
          {[
            { label: 'Completion Rate', value: `${completionRate}%`, color: '#22c55e' },
            { label: 'Total Equipment', value: stats.total_equipment || 0, color: '#141414' },
            { label: 'Active Packages', value: data?.packageBreakdown?.length || 0, color: '#007b8a' },
            { label: 'Pending Orders', value: stats.order_not_placed || 0, color: '#ff7700' },
          ].map(({ label, value, color }) => (
            <div key={label} className="stat-card" style={{ '--accent-color': color }}>
              <div className="stat-card-value" style={{ color }}>{value}</div>
              <div className="stat-card-label">{label}</div>
            </div>
          ))}
        </div>

        <div className="grid-2 mb-6">
          {/* Status Bar Chart */}
          <div className="card">
            <div className="card-header"><span className="card-title">Equipment Count by Status</span></div>
            <ResponsiveContainer width="100%" height={260}>
              <BarChart data={statusData} layout="vertical" margin={{ left: 80, right: 20 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="var(--border-subtle)" horizontal={false} />
                <XAxis type="number" tick={{ fill: 'var(--text-muted)', fontSize: 11 }} />
                <YAxis type="category" dataKey="name" tick={{ fill: 'var(--text-secondary)', fontSize: 10 }} width={80} />
                <Tooltip
                  formatter={(v, n, p) => [v, p.payload.fullName]}
                  contentStyle={{ background: 'var(--bg-card)', border: '1px solid var(--border-default)', borderRadius: 8, fontSize: 12 }}
                />
                <Bar dataKey="count" radius={[0, 4, 4, 0]}>
                  {statusData.map((entry, i) => <Cell key={i} fill={entry.color} />)}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>

          {/* Pie + table */}
          <div className="card">
            <div className="card-header"><span className="card-title">Distribution Breakdown</span></div>
            <div style={{ display: 'flex', gap: 16 }}>
              <ResponsiveContainer width="50%" height={200}>
                <PieChart>
                  <Pie data={statusData.filter(d => d.count > 0)} dataKey="count" cx="50%" cy="50%" outerRadius={70} innerRadius={35}>
                    {statusData.filter(d => d.count > 0).map((e, i) => <Cell key={i} fill={e.color} />)}
                  </Pie>
                  <Tooltip formatter={(v, n, p) => [v, p.payload.fullName]}
                    contentStyle={{ background: 'var(--bg-card)', border: '1px solid var(--border-default)', borderRadius: 8, fontSize: 12 }} />
                </PieChart>
              </ResponsiveContainer>
              <div style={{ flex: 1, overflow: 'auto' }}>
                {statusData.map(s => (
                  <div key={s.name} style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '4px 0', borderBottom: '1px solid var(--border-subtle)' }}>
                    <div style={{ width: 8, height: 8, borderRadius: '50%', background: s.color, flexShrink: 0 }} />
                    <span style={{ fontSize: 11, color: 'var(--text-secondary)', flex: 1 }}>{s.fullName}</span>
                    <span style={{ fontSize: 12, fontWeight: 700, color: s.color }}>{s.count}</span>
                    <span style={{ fontSize: 10, color: 'var(--text-muted)' }}>{s.pct}%</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Summary Table */}
        <div className="card">
          <div className="card-header">
            <span className="card-title">Status Summary Report</span>
            <button className="btn btn-primary btn-sm" onClick={equipmentAPI.export}>Export to Excel</button>
          </div>
          <div className="table-container">
            <table>
              <thead>
                <tr>
                  <th>Status Code</th>
                  <th>Status Name</th>
                  <th>Equipment Count</th>
                  <th>% of Total</th>
                  <th>Progress</th>
                </tr>
              </thead>
              <tbody>
                {statusData.map(s => (
                  <tr key={s.name}>
                    <td><span className="tag">{(data?.statusBreakdown || []).find(sb => sb.status_name === s.fullName)?.status_code ?? '—'}</span></td>
                    <td style={{ color: s.color, fontWeight: 500 }}>{s.fullName}</td>
                    <td style={{ fontWeight: 700, color: 'var(--text-primary)' }}>{s.count}</td>
                    <td style={{ color: 'var(--text-secondary)' }}>{s.pct}%</td>
                    <td style={{ width: 160 }}>
                      <div className="progress-track">
                        <div className="progress-fill" style={{ width: `${s.pct}%`, background: s.color }} />
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

      </div>
    </>
  );
}
