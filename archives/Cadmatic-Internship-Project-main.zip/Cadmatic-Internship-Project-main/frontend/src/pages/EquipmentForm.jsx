import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import toast from 'react-hot-toast';
import { ArrowLeft, Save } from 'lucide-react';
import Topbar from '../components/Topbar';
import { equipmentAPI } from '../services/api';
import { STATUS_MAP } from '../utils/statusUtils';

const initialForm = {
  position_id: '', storage_number: '', epc_po_number: '', sub_po_number: '',
  sub_po_vendor: '', equipment_status_code: 0, npcil_spec_number: '', npcil_spec_status: '',
  drawing_number: '', drawing_status: '', data_sheet_number: '', data_sheet_status: '',
  as_built_drawing_number: '', epc_package_name: '', equip_status: 'Order Not Yet Placed',
  location: '', equipment_type: '', last_inspection_date: '', next_inspection_date: '',
};

const specStatusOptions = ['Spec Not Issued', 'Spec Issued'];
const drawingStatusOptions = ['Drawing Not Issued', 'Drawing Issued'];

export default function EquipmentForm() {
  const { id } = useParams();
  const navigate = useNavigate();
  const isEdit = !!id && id !== 'new';
  const [form, setForm] = useState(initialForm);
  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (!isEdit) return;
    setLoading(true);
    equipmentAPI.getById(id)
      .then(res => {
        const d = res.data.data;
        setForm({
          ...initialForm, ...d,
          last_inspection_date: d.last_inspection_date ? d.last_inspection_date.split('T')[0] : '',
          next_inspection_date: d.next_inspection_date ? d.next_inspection_date.split('T')[0] : '',
        });
      })
      .catch(() => toast.error('Failed to load equipment'))
      .finally(() => setLoading(false));
  }, [id, isEdit]);

  const handleChange = (key, value) => {
    setForm(f => {
      const updated = { ...f, [key]: value };
      // Auto-sync status name from code
      if (key === 'equipment_status_code') {
        updated.equip_status = STATUS_MAP[value]?.name || '';
      }
      return updated;
    });
  };

  const handleSubmit = async () => {
    if (!form.position_id.trim()) { toast.error('Position ID is required'); return; }
    setSaving(true);
    try {
      if (isEdit) {
        await equipmentAPI.update(id, form);
        toast.success('Equipment updated successfully');
        navigate(`/equipment/${id}`);
      } else {
        const res = await equipmentAPI.create(form);
        toast.success('Equipment created successfully');
        navigate(`/equipment/${res.data.id}`);
      }
    } catch (err) {
      toast.error(err.message);
    } finally {
      setSaving(false);
    }
  };

  const Input = ({ label, field, type = 'text', required }) => (
    <div className="form-group">
      <label className="form-label">{label}{required && ' *'}</label>
      <input type={type} className="form-control" value={form[field] || ''}
        onChange={e => handleChange(field, e.target.value)} />
    </div>
  );

  const Select = ({ label, field, options }) => (
    <div className="form-group">
      <label className="form-label">{label}</label>
      <select className="form-control" value={form[field] || ''}
        onChange={e => handleChange(field, e.target.value)}>
        <option value="">— Select —</option>
        {options.map(o => <option key={o.value ?? o} value={o.value ?? o}>{o.label ?? o}</option>)}
      </select>
    </div>
  );

  if (loading) return (
    <>
      <Topbar title={isEdit ? 'Edit Equipment' : 'Add Equipment'} onRefresh={() => {}} />
      <div className="page-content"><div className="page-loader"><div className="loading-spinner" /></div></div>
    </>
  );

  return (
    <>
      <Topbar title={isEdit ? `Edit: ${form.position_id}` : 'Add New Equipment'} subtitle={isEdit ? 'Update equipment details' : 'Register a new equipment'} onRefresh={() => {}} />
      <div className="page-content">

        <div className="flex items-center justify-between mb-6">
          <button className="btn btn-secondary btn-sm" onClick={() => navigate(isEdit ? `/equipment/${id}` : '/equipment')}>
            <ArrowLeft size={14} /> Back
          </button>
          <button className="btn btn-primary" onClick={handleSubmit} disabled={saving}>
            {saving ? <><div className="loading-spinner" style={{ width: 14, height: 14 }} /> Saving...</> : <><Save size={14} /> {isEdit ? 'Update Equipment' : 'Create Equipment'}</>}
          </button>
        </div>

        <div className="grid-2 mb-4">
          {/* Basic Info */}
          <div className="card">
            <div className="card-header"><span className="card-title">📋 Basic Information</span></div>
            <Input label="Position ID" field="position_id" required />
            <Input label="Storage Number" field="storage_number" />
            <Input label="EPC Package Name" field="epc_package_name" />
            <Input label="Equipment Type" field="equipment_type" />
            <Input label="Location" field="location" />
          </div>

          {/* PO Info */}
          <div className="card">
            <div className="card-header"><span className="card-title">📦 Purchase Order</span></div>
            <Input label="EPC PO Number" field="epc_po_number" />
            <Input label="Sub PO Number" field="sub_po_number" />
            <Input label="Sub PO Vendor" field="sub_po_vendor" />
            <Input label="Last Inspection Date" field="last_inspection_date" type="date" />
            <Input label="Next Inspection Date" field="next_inspection_date" type="date" />
          </div>
        </div>

        <div className="grid-2 mb-4">
          {/* Status */}
          <div className="card">
            <div className="card-header"><span className="card-title">🚦 Equipment Status</span></div>
            <div className="form-group">
              <label className="form-label">Status Code *</label>
              <select className="form-control" value={form.equipment_status_code}
                onChange={e => handleChange('equipment_status_code', parseInt(e.target.value))}>
                {Object.entries(STATUS_MAP).map(([code, info]) => (
                  <option key={code} value={code}>{code} — {info.name}</option>
                ))}
              </select>
            </div>
            <div className="form-group">
              <label className="form-label">Status Label</label>
              <input className="form-control" value={form.equip_status || ''}
                onChange={e => handleChange('equip_status', e.target.value)} />
            </div>
          </div>

          {/* Documentation */}
          <div className="card">
            <div className="card-header"><span className="card-title">📄 Documentation</span></div>
            <div className="grid-2">
              <Input label="NPCIL Spec Number" field="npcil_spec_number" />
              <Select label="Spec Status" field="npcil_spec_status" options={specStatusOptions} />
              <Input label="Drawing Number" field="drawing_number" />
              <Select label="Drawing Status" field="drawing_status" options={drawingStatusOptions} />
              <Input label="Data Sheet Number" field="data_sheet_number" />
              <Select label="Data Sheet Status" field="data_sheet_status" options={drawingStatusOptions} />
            </div>
            <Input label="As-Built Drawing Number" field="as_built_drawing_number" />
          </div>
        </div>

        <div className="flex justify-between">
          <button className="btn btn-secondary" onClick={() => navigate(isEdit ? `/equipment/${id}` : '/equipment')}>
            Cancel
          </button>
          <button className="btn btn-primary btn-lg" onClick={handleSubmit} disabled={saving}>
            {saving ? 'Saving...' : isEdit ? 'Update Equipment' : 'Create Equipment'}
          </button>
        </div>
      </div>
    </>
  );
}
