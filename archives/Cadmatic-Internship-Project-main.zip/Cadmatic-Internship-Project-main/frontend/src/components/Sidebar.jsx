import React from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import {
  LayoutDashboard, ListChecks, PlusCircle, Upload,
  BarChart3, Boxes
} from 'lucide-react';

const navItems = [
  { icon: LayoutDashboard, label: 'Dashboard', path: '/' },
  { icon: ListChecks, label: 'Equipment List', path: '/equipment' },
  { icon: PlusCircle, label: 'Add Equipment', path: '/equipment/new' },
  { icon: Upload, label: 'Import / Export', path: '/import' },
  { icon: BarChart3, label: 'Reports', path: '/reports' },
];

export default function Sidebar() {
  const navigate = useNavigate();
  const { pathname } = useLocation();

  return (
    <aside className="sidebar">
      <div className="sidebar-logo">
        <div className="sidebar-logo-inner">
          <div className="sidebar-logo-icon">
            <Boxes size={21} color="#141414" strokeWidth={2.4} />
          </div>
          <div className="sidebar-logo-text">
            <h1>Cadmatic EMS</h1>
            <p>Equipment Monitoring</p>
          </div>
        </div>
      </div>

      <div className="sidebar-section">
        <div className="sidebar-section-label">Navigation</div>
        {navItems.map(({ icon: Icon, label, path }) => (
          <button
            key={path}
            className={`sidebar-nav-item ${pathname === path ? 'active' : ''}`}
            onClick={() => navigate(path)}
          >
            <Icon size={16} />
            {label}
          </button>
        ))}
      </div>

      <div className="sidebar-bottom">
        <div className="sidebar-nav-item" style={{ cursor: 'default' }}>
          <div className="status-dot" />
          <span style={{ fontSize: '12px', color: 'rgba(255,255,255,0.62)' }}>System Online</span>
        </div>
        <div style={{ padding: '4px 12px', fontSize: '11px', color: 'rgba(255,255,255,0.42)' }}>
          v1.0.0 - EMS
        </div>
      </div>
    </aside>
  );
}
