import axios from 'axios';

const API = axios.create({
  baseURL: process.env.REACT_APP_API_URL || '/api',
  timeout: 30000,
  headers: { 'Content-Type': 'application/json' },
});

API.interceptors.response.use(
  (res) => res,
  (err) => {
    const msg = err.response?.data?.message || err.message || 'Request failed';
    return Promise.reject(new Error(msg));
  }
);

export const equipmentAPI = {
  getAll: (params) => API.get('/equipment', { params }),
  getById: (id) => API.get(`/equipment/${id}`),
  create: (data) => API.post('/equipment', data),
  update: (id, data) => API.put(`/equipment/${id}`, data),
  delete: (id) => API.delete(`/equipment/${id}`),
  getDashboard: () => API.get('/equipment/stats/dashboard'),
  getStatusLookup: () => API.get('/equipment/status-lookup'),
  import: (formData) => API.post('/equipment/import/excel', formData, {
    headers: { 'Content-Type': 'multipart/form-data' }
  }),
  export: () => window.open('/api/equipment/export', '_blank'),
  addMaintenance: (id, data) => API.post(`/equipment/${id}/maintenance`, data),
};

export default API;
