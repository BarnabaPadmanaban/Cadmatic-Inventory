const express = require('express');
const router = express.Router();
const multer = require('multer');
const path = require('path');
const ctrl = require('../controllers/equipmentController');

const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, path.join(__dirname, '../../uploads')),
  filename: (req, file, cb) => cb(null, `import_${Date.now()}${path.extname(file.originalname)}`)
});
const upload = multer({
  storage,
  fileFilter: (req, file, cb) => {
    const allowed = ['.xlsx', '.xls'];
    if (allowed.includes(path.extname(file.originalname).toLowerCase())) cb(null, true);
    else cb(new Error('Only Excel files allowed'));
  },
  limits: { fileSize: 10 * 1024 * 1024 }
});

router.get('/', ctrl.getAllEquipment);
router.get('/stats/dashboard', ctrl.getDashboardStats);
router.get('/status-lookup', ctrl.getStatusLookup);
router.get('/export', ctrl.exportToExcel);
router.get('/:id', ctrl.getEquipmentById);
router.post('/', ctrl.createEquipment);
router.put('/:id', ctrl.updateEquipment);
router.delete('/:id', ctrl.deleteEquipment);
router.post('/import/excel', upload.single('file'), ctrl.importFromExcel);
router.post('/:id/maintenance', ctrl.addMaintenanceRecord);

module.exports = router;
