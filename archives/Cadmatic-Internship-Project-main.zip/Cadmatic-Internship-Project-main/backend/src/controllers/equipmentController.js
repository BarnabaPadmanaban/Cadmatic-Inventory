const { sql, getPool } = require('../config/database');
const xlsx = require('xlsx');
const path = require('path');
const devStore = require('../devStore');

const canUseDevFallback = () => process.env.NODE_ENV === 'development' && process.env.ENABLE_DEV_FALLBACK !== 'false';

const isConnectionError = (err) => {
  const message = String(err?.message || '').toLowerCase();
  return message.includes('failed to connect') ||
    message.includes('could not connect') ||
    message.includes('login failed') ||
    message.includes('econnrefused') ||
    message.includes('connection');
};

const handleDbError = (res, err, fallback) => {
  if (canUseDevFallback() && isConnectionError(err)) {
    console.warn(`Using development fallback data: ${err.message}`);
    return fallback();
  }
  return res.status(500).json({ success: false, message: err.message || 'Server error' });
};

// GET all equipment with filters
exports.getAllEquipment = async (req, res) => {
  try {
    const pool = await getPool();
    const { search, status, package_name, type, page = 1, limit = 50 } = req.query;
    const offset = (parseInt(page) - 1) * parseInt(limit);

    let whereClause = 'WHERE e.is_active = 1';
    const request = pool.request();

    if (search) {
      whereClause += ` AND (e.position_id LIKE @search OR e.equip_status LIKE @search OR e.location LIKE @search OR e.sub_po_vendor LIKE @search OR e.epc_package_name LIKE @search)`;
      request.input('search', sql.NVarChar, `%${search}%`);
    }
    if (status !== undefined && status !== '') {
      whereClause += ` AND e.equipment_status_code = @status`;
      request.input('status', sql.Int, parseInt(status));
    }
    if (package_name) {
      whereClause += ` AND e.epc_package_name = @package_name`;
      request.input('package_name', sql.NVarChar, package_name);
    }
    if (type) {
      whereClause += ` AND e.equipment_type = @type`;
      request.input('type', sql.NVarChar, type);
    }

    const countResult = await pool.request().query(`SELECT COUNT(*) AS total FROM Equipment e ${whereClause.replace(/@\w+/g, (m) => {
      // Re-add params for count query
      return m;
    })}`);

    // Count query with same filters
    const countReq = pool.request();
    if (search) countReq.input('search', sql.NVarChar, `%${search}%`);
    if (status !== undefined && status !== '') countReq.input('status', sql.Int, parseInt(status));
    if (package_name) countReq.input('package_name', sql.NVarChar, package_name);
    if (type) countReq.input('type', sql.NVarChar, type);
    const totalResult = await countReq.query(`SELECT COUNT(*) AS total FROM Equipment e ${whereClause}`);
    const total = totalResult.recordset[0].total;

    request.input('limit', sql.Int, parseInt(limit));
    request.input('offset', sql.Int, offset);

    const result = await request.query(`
      SELECT 
        e.id, e.position_id, e.storage_number, e.epc_po_number, e.sub_po_number,
        e.sub_po_vendor, e.equipment_status_code, e.npcil_spec_number, e.npcil_spec_status,
        e.drawing_number, e.drawing_status, e.data_sheet_number, e.data_sheet_status,
        e.as_built_drawing_number, e.epc_package_name, e.equip_status, e.location,
        e.equipment_type, e.last_inspection_date, e.next_inspection_date,
        e.created_at, e.updated_at,
        s.status_name, s.status_color
      FROM Equipment e
      LEFT JOIN StatusLookup s ON e.equipment_status_code = s.status_code
      ${whereClause}
      ORDER BY e.equipment_status_code ASC, e.position_id ASC
      OFFSET @offset ROWS FETCH NEXT @limit ROWS ONLY
    `);

    res.json({
      success: true,
      data: result.recordset,
      pagination: { page: parseInt(page), limit: parseInt(limit), total, pages: Math.ceil(total / parseInt(limit)) }
    });
  } catch (err) {
    console.error('getAllEquipment error:', err);
    return handleDbError(res, err, () => {
      const result = devStore.getAllEquipment(req.query);
      res.json({ success: true, ...result });
    });
  }
};

// GET single equipment by ID
exports.getEquipmentById = async (req, res) => {
  try {
    const pool = await getPool();
    const result = await pool.request()
      .input('id', sql.Int, req.params.id)
      .query(`
        SELECT e.*, s.status_name, s.status_color, s.description AS status_description
        FROM Equipment e
        LEFT JOIN StatusLookup s ON e.equipment_status_code = s.status_code
        WHERE e.id = @id AND e.is_active = 1
      `);

    if (!result.recordset.length) return res.status(404).json({ success: false, message: 'Equipment not found' });

    const maintenance = await pool.request()
      .input('eid', sql.Int, req.params.id)
      .query(`SELECT * FROM MaintenanceRecords WHERE equipment_id = @eid ORDER BY maintenance_date DESC`);

    res.json({ success: true, data: { ...result.recordset[0], maintenance_history: maintenance.recordset } });
  } catch (err) {
    return handleDbError(res, err, () => {
      const item = devStore.getEquipmentById(req.params.id);
      if (!item) return res.status(404).json({ success: false, message: 'Equipment not found' });
      res.json({ success: true, data: item });
    });
  }
};

// CREATE equipment
exports.createEquipment = async (req, res) => {
  try {
    const pool = await getPool();
    const d = req.body;

    const result = await pool.request()
      .input('position_id', sql.NVarChar, d.position_id)
      .input('storage_number', sql.NVarChar, d.storage_number || null)
      .input('epc_po_number', sql.NVarChar, d.epc_po_number || null)
      .input('sub_po_number', sql.NVarChar, d.sub_po_number || null)
      .input('sub_po_vendor', sql.NVarChar, d.sub_po_vendor || null)
      .input('equipment_status_code', sql.Int, d.equipment_status_code || 0)
      .input('npcil_spec_number', sql.NVarChar, d.npcil_spec_number || null)
      .input('npcil_spec_status', sql.NVarChar, d.npcil_spec_status || null)
      .input('drawing_number', sql.NVarChar, d.drawing_number || null)
      .input('drawing_status', sql.NVarChar, d.drawing_status || null)
      .input('data_sheet_number', sql.NVarChar, d.data_sheet_number || null)
      .input('data_sheet_status', sql.NVarChar, d.data_sheet_status || null)
      .input('as_built_drawing_number', sql.NVarChar, d.as_built_drawing_number || null)
      .input('epc_package_name', sql.NVarChar, d.epc_package_name || null)
      .input('equip_status', sql.NVarChar, d.equip_status || null)
      .input('location', sql.NVarChar, d.location || null)
      .input('equipment_type', sql.NVarChar, d.equipment_type || null)
      .input('last_inspection_date', sql.Date, d.last_inspection_date || null)
      .input('next_inspection_date', sql.Date, d.next_inspection_date || null)
      .query(`
        INSERT INTO Equipment (position_id, storage_number, epc_po_number, sub_po_number, sub_po_vendor, equipment_status_code, npcil_spec_number, npcil_spec_status, drawing_number, drawing_status, data_sheet_number, data_sheet_status, as_built_drawing_number, epc_package_name, equip_status, location, equipment_type, last_inspection_date, next_inspection_date)
        OUTPUT INSERTED.id
        VALUES (@position_id, @storage_number, @epc_po_number, @sub_po_number, @sub_po_vendor, @equipment_status_code, @npcil_spec_number, @npcil_spec_status, @drawing_number, @drawing_status, @data_sheet_number, @data_sheet_status, @as_built_drawing_number, @epc_package_name, @equip_status, @location, @equipment_type, @last_inspection_date, @next_inspection_date)
      `);

    res.status(201).json({ success: true, message: 'Equipment created', id: result.recordset[0].id });
  } catch (err) {
    return handleDbError(res, err, () => {
      const id = devStore.createEquipment(req.body);
      res.status(201).json({ success: true, message: 'Equipment created', id });
    });
  }
};

// UPDATE equipment
exports.updateEquipment = async (req, res) => {
  try {
    const pool = await getPool();
    const d = req.body;

    await pool.request()
      .input('id', sql.Int, req.params.id)
      .input('equipment_status_code', sql.Int, d.equipment_status_code)
      .input('equip_status', sql.NVarChar, d.equip_status)
      .input('location', sql.NVarChar, d.location)
      .input('equipment_type', sql.NVarChar, d.equipment_type)
      .input('npcil_spec_status', sql.NVarChar, d.npcil_spec_status)
      .input('drawing_status', sql.NVarChar, d.drawing_status)
      .input('data_sheet_status', sql.NVarChar, d.data_sheet_status)
      .input('last_inspection_date', sql.Date, d.last_inspection_date || null)
      .input('next_inspection_date', sql.Date, d.next_inspection_date || null)
      .input('sub_po_vendor', sql.NVarChar, d.sub_po_vendor)
      .query(`
        UPDATE Equipment SET
          equipment_status_code = @equipment_status_code,
          equip_status = @equip_status,
          location = @location,
          equipment_type = @equipment_type,
          npcil_spec_status = @npcil_spec_status,
          drawing_status = @drawing_status,
          data_sheet_status = @data_sheet_status,
          last_inspection_date = @last_inspection_date,
          next_inspection_date = @next_inspection_date,
          sub_po_vendor = @sub_po_vendor,
          updated_at = GETDATE()
        WHERE id = @id
      `);

    res.json({ success: true, message: 'Equipment updated successfully' });
  } catch (err) {
    return handleDbError(res, err, () => {
      const updated = devStore.updateEquipment(req.params.id, req.body);
      if (!updated) return res.status(404).json({ success: false, message: 'Equipment not found' });
      res.json({ success: true, message: 'Equipment updated successfully' });
    });
  }
};

// DELETE (soft) equipment
exports.deleteEquipment = async (req, res) => {
  try {
    const pool = await getPool();
    await pool.request()
      .input('id', sql.Int, req.params.id)
      .query(`UPDATE Equipment SET is_active = 0, updated_at = GETDATE() WHERE id = @id`);
    res.json({ success: true, message: 'Equipment deleted' });
  } catch (err) {
    return handleDbError(res, err, () => {
      const deleted = devStore.deleteEquipment(req.params.id);
      if (!deleted) return res.status(404).json({ success: false, message: 'Equipment not found' });
      res.json({ success: true, message: 'Equipment deleted' });
    });
  }
};

// GET dashboard stats
exports.getDashboardStats = async (req, res) => {
  try {
    const pool = await getPool();

    const statsResult = await pool.request().query(`
      SELECT 
        COUNT(*) AS total_equipment,
        SUM(CASE WHEN equipment_status_code = 8 THEN 1 ELSE 0 END) AS commissioned,
        SUM(CASE WHEN equipment_status_code = 7 THEN 1 ELSE 0 END) AS handover_om,
        SUM(CASE WHEN equipment_status_code = 0 THEN 1 ELSE 0 END) AS order_not_placed,
        SUM(CASE WHEN equipment_status_code BETWEEN 1 AND 4 THEN 1 ELSE 0 END) AS in_progress,
        SUM(CASE WHEN equipment_status_code IN (5, 6) THEN 1 ELSE 0 END) AS testing_phase
      FROM Equipment WHERE is_active = 1
    `);

    const statusBreakdown = await pool.request().query(`
      SELECT s.status_code, s.status_name, s.status_color, COUNT(e.id) AS count
      FROM StatusLookup s
      LEFT JOIN Equipment e ON s.status_code = e.equipment_status_code AND e.is_active = 1
      GROUP BY s.status_code, s.status_name, s.status_color
      ORDER BY s.status_code
    `);

    const packageBreakdown = await pool.request().query(`
      SELECT epc_package_name, COUNT(*) AS count
      FROM Equipment WHERE is_active = 1 AND epc_package_name IS NOT NULL
      GROUP BY epc_package_name
      ORDER BY count DESC
    `);

    const recentActivity = await pool.request().query(`
      SELECT TOP 10 position_id, equip_status, location, updated_at
      FROM Equipment WHERE is_active = 1
      ORDER BY updated_at DESC
    `);

    res.json({
      success: true,
      data: {
        stats: statsResult.recordset[0],
        statusBreakdown: statusBreakdown.recordset,
        packageBreakdown: packageBreakdown.recordset,
        recentActivity: recentActivity.recordset
      }
    });
  } catch (err) {
    return handleDbError(res, err, () => {
      res.json({ success: true, data: devStore.getDashboardStats() });
    });
  }
};

// IMPORT from Excel
exports.importFromExcel = async (req, res) => {
  try {
    if (!req.file) return res.status(400).json({ success: false, message: 'No file uploaded' });
    const pool = await getPool();

    const workbook = xlsx.readFile(req.file.path);
    const sheetName = workbook.SheetNames[0];
    const sheet = workbook.Sheets[sheetName];
    const rows = xlsx.utils.sheet_to_json(sheet);

    const statusMap = {
      'order not yet placed': 0, 'order not yer placed': 0,
      'order placed': 1, 'order placed yes': 1,
      'shipping release issued': 2,
      'received at site': 3,
      'erected at location': 4, 'erected at location.': 4,
      'hydro tested': 5,
      'ccc/std released': 6, 'ccc/std released.': 6,
      'handover to o&m': 7,
      'commissioned': 8, 'commisioned': 8
    };

    let imported = 0, skipped = 0;

    for (const row of rows) {
      const posId = row['nam Position Id'] || row['position_id'];
      if (!posId || posId === 'NaN') { skipped++; continue; }

      const equipStatusRaw = (row['Equip Status'] || row['equip_status'] || '').trim().toLowerCase();
      const statusCode = statusMap[equipStatusRaw] ?? 0;

      const existing = await pool.request()
        .input('pid', sql.NVarChar, posId.toString().trim())
        .query('SELECT id FROM Equipment WHERE position_id = @pid');

      if (existing.recordset.length > 0) { skipped++; continue; }

      await pool.request()
        .input('position_id', sql.NVarChar, posId.toString().trim())
        .input('storage_number', sql.NVarChar, row['Storage Number'] || null)
        .input('epc_po_number', sql.NVarChar, row['EPC Purchase Order Number'] || null)
        .input('sub_po_number', sql.NVarChar, row['Sub Purchase Order Number'] || null)
        .input('sub_po_vendor', sql.NVarChar, row['Sub PO Vendor Name'] || null)
        .input('equipment_status_code', sql.Int, statusCode)
        .input('npcil_spec_number', sql.NVarChar, row['NPCIL Spec Number'] || null)
        .input('npcil_spec_status', sql.NVarChar, row['NPCIL Spec Status'] || null)
        .input('drawing_number', sql.NVarChar, row['Drawing Number'] || null)
        .input('drawing_status', sql.NVarChar, row['Drawing Status'] || null)
        .input('data_sheet_number', sql.NVarChar, row['Data Sheet Number'] || null)
        .input('data_sheet_status', sql.NVarChar, row['Data Sheet Status'] || null)
        .input('as_built_drawing_number', sql.NVarChar, row['As - Built Drawing Number'] || null)
        .input('epc_package_name', sql.NVarChar, row['EPC Package Name'] || null)
        .input('equip_status', sql.NVarChar, row['Equip Status'] || null)
        .query(`INSERT INTO Equipment (position_id, storage_number, epc_po_number, sub_po_number, sub_po_vendor, equipment_status_code, npcil_spec_number, npcil_spec_status, drawing_number, drawing_status, data_sheet_number, data_sheet_status, as_built_drawing_number, epc_package_name, equip_status)
                VALUES (@position_id, @storage_number, @epc_po_number, @sub_po_number, @sub_po_vendor, @equipment_status_code, @npcil_spec_number, @npcil_spec_status, @drawing_number, @drawing_status, @data_sheet_number, @data_sheet_status, @as_built_drawing_number, @epc_package_name, @equip_status)`);
      imported++;
    }

    const fs = require('fs');
    fs.unlinkSync(req.file.path);

    res.json({ success: true, message: `Import complete. ${imported} records imported, ${skipped} skipped.`, imported, skipped });
  } catch (err) {
    return handleDbError(res, err, () => {
      res.status(500).json({ success: false, message: 'Excel import requires a SQL Server connection in this build.' });
    });
  }
};

// EXPORT to Excel
exports.exportToExcel = async (req, res) => {
  try {
    const pool = await getPool();
    const result = await pool.request().query(`
      SELECT e.position_id AS "Position ID", e.storage_number AS "Storage Number",
        e.epc_po_number AS "EPC PO Number", e.sub_po_number AS "Sub PO Number",
        e.sub_po_vendor AS "Vendor", s.status_name AS "Status",
        e.npcil_spec_number AS "NPCIL Spec", e.npcil_spec_status AS "Spec Status",
        e.drawing_number AS "Drawing No", e.drawing_status AS "Drawing Status",
        e.data_sheet_number AS "Data Sheet", e.data_sheet_status AS "Data Sheet Status",
        e.epc_package_name AS "Package", e.equip_status AS "Equipment Status",
        e.location AS "Location", e.equipment_type AS "Type",
        CONVERT(VARCHAR, e.last_inspection_date, 103) AS "Last Inspection",
        CONVERT(VARCHAR, e.updated_at, 103) AS "Last Updated"
      FROM Equipment e
      LEFT JOIN StatusLookup s ON e.equipment_status_code = s.status_code
      WHERE e.is_active = 1
      ORDER BY e.position_id
    `);

    const wb = xlsx.utils.book_new();
    const ws = xlsx.utils.json_to_sheet(result.recordset);
    xlsx.utils.book_append_sheet(wb, ws, 'Equipment Status');
    const buffer = xlsx.write(wb, { type: 'buffer', bookType: 'xlsx' });

    res.setHeader('Content-Disposition', 'attachment; filename="equipment_status_export.xlsx"');
    res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    res.send(buffer);
  } catch (err) {
    return handleDbError(res, err, () => {
      const buffer = devStore.exportWorkbook();
      res.setHeader('Content-Disposition', 'attachment; filename="equipment_status_export.xlsx"');
      res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
      res.send(buffer);
    });
  }
};

// GET status lookup
exports.getStatusLookup = async (req, res) => {
  try {
    const pool = await getPool();
    const result = await pool.request().query('SELECT * FROM StatusLookup ORDER BY status_code');
    res.json({ success: true, data: result.recordset });
  } catch (err) {
    return handleDbError(res, err, () => {
      res.json({ success: true, data: devStore.statuses });
    });
  }
};

// ADD maintenance record
exports.addMaintenanceRecord = async (req, res) => {
  try {
    const pool = await getPool();
    const d = req.body;
    await pool.request()
      .input('equipment_id', sql.Int, req.params.id)
      .input('maintenance_type', sql.NVarChar, d.maintenance_type)
      .input('description', sql.NVarChar, d.description)
      .input('performed_by', sql.NVarChar, d.performed_by)
      .input('next_maintenance_date', sql.Date, d.next_maintenance_date || null)
      .input('status', sql.NVarChar, d.status || 'Completed')
      .input('remarks', sql.NVarChar, d.remarks || null)
      .query(`INSERT INTO MaintenanceRecords (equipment_id, maintenance_type, description, performed_by, next_maintenance_date, status, remarks)
              VALUES (@equipment_id, @maintenance_type, @description, @performed_by, @next_maintenance_date, @status, @remarks)`);
    res.status(201).json({ success: true, message: 'Maintenance record added' });
  } catch (err) {
    return handleDbError(res, err, () => {
      const item = devStore.getEquipmentById(req.params.id);
      if (!item) return res.status(404).json({ success: false, message: 'Equipment not found' });
      devStore.addMaintenanceRecord(req.params.id, req.body);
      res.status(201).json({ success: true, message: 'Maintenance record added' });
    });
  }
};
