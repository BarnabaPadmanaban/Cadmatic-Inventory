const { sql, getPool } = require('../config/database');

const seedData = async () => {
  const pool = await getPool();

  const equipment = [
    { position_id: '3200-P-01', storage_number: 'SN-25478', epc_po_number: 'EPC PO 12345', sub_po_number: 'SUB PO 478', sub_po_vendor: 'SUB PO Vendor', equipment_status_code: 0, npcil_spec_number: 'PC-E-165', npcil_spec_status: 'Spec Not Issued', drawing_number: '1&2-2358-DD', drawing_status: 'Drawing Issued', data_sheet_number: 'Data Sheet', data_sheet_status: 'Drawing Issued', as_built_drawing_number: 'As Built', epc_package_name: 'NIMEP', equip_status: 'Order Not Yet Placed', location: 'Unit 1 - Pump House', equipment_type: 'Pump', last_inspection_date: '2024-01-15' },
    { position_id: '3200-P-02', storage_number: 'SN-25478', epc_po_number: 'EPC PO 12345', sub_po_number: 'SUB PO 478', sub_po_vendor: 'SUB PO Vendor', equipment_status_code: 1, npcil_spec_number: 'PC-E-165', npcil_spec_status: 'Spec Issued', drawing_number: '1&2-2358-DD', drawing_status: 'Drawing Issued', data_sheet_number: 'Data Sheet', data_sheet_status: 'Drawing Issued', as_built_drawing_number: 'As Built', epc_package_name: 'NIMEP', equip_status: 'Order Placed', location: 'Unit 1 - Pump House', equipment_type: 'Pump', last_inspection_date: '2024-02-10' },
    { position_id: '3200-P-03', storage_number: 'SN-25478', epc_po_number: 'EPC PO 12345', sub_po_number: 'SUB PO 478', sub_po_vendor: 'SUB PO Vendor', equipment_status_code: 2, npcil_spec_number: 'PC-E-165', npcil_spec_status: 'Spec Not Issued', drawing_number: '1&2-2358-DD', drawing_status: 'Drawing Not Issued', data_sheet_number: 'Data Sheet', data_sheet_status: 'Drawing Not Issued', as_built_drawing_number: 'As Built', epc_package_name: 'NIMEP', equip_status: 'Shipping Release Issued', location: 'Unit 2 - Pump House', equipment_type: 'Pump', last_inspection_date: '2024-03-05' },
    { position_id: '3200-P-04', storage_number: 'SN-25478', epc_po_number: 'EPC PO 12345', sub_po_number: 'SUB PO 478', sub_po_vendor: 'SUB PO Vendor', equipment_status_code: 3, npcil_spec_number: 'PC-E-165', npcil_spec_status: 'Spec Issued', drawing_number: '1&2-2358-DD', drawing_status: 'Drawing Not Issued', data_sheet_number: 'Data Sheet', data_sheet_status: 'Drawing Not Issued', as_built_drawing_number: 'As Built', epc_package_name: 'NIMEP', equip_status: 'Received at Site', location: 'Unit 2 - Storage Yard', equipment_type: 'Pump', last_inspection_date: '2024-03-20' },
    { position_id: '3200-P-05', storage_number: 'SN-25478', epc_po_number: 'EPC PO 12345', sub_po_number: 'SUB PO 478', sub_po_vendor: 'SUB PO Vendor', equipment_status_code: 8, npcil_spec_number: 'PC-E-165', npcil_spec_status: 'Spec Not Issued', drawing_number: '1&2-2358-DD', drawing_status: 'Drawing Not Issued', data_sheet_number: 'Data Sheet', data_sheet_status: 'Drawing Not Issued', as_built_drawing_number: 'As Built', epc_package_name: 'NIMEP', equip_status: 'Commissioned', location: 'Unit 1 - Control Room', equipment_type: 'Pump', last_inspection_date: '2024-04-12' },
    { position_id: '3200-P-06', storage_number: 'SN-25478', epc_po_number: 'EPC PO 12345', sub_po_number: 'SUB PO 478', sub_po_vendor: 'SUB PO Vendor', equipment_status_code: 7, npcil_spec_number: 'PC-E-165', npcil_spec_status: 'Spec Issued', drawing_number: '1&2-2358-DD', drawing_status: 'Drawing Not Issued', data_sheet_number: 'Data Sheet', data_sheet_status: 'Drawing Not Issued', as_built_drawing_number: 'As Built', epc_package_name: 'NIMEP', equip_status: 'Handover to O&M', location: 'Unit 1 - Turbine Hall', equipment_type: 'Pump', last_inspection_date: '2024-04-25' },
    { position_id: '6-3221-P-01', storage_number: 'SN-25478', epc_po_number: 'EPC PO 12345', sub_po_number: 'SUB PO 478', sub_po_vendor: 'SUB PO Vendor', equipment_status_code: 6, npcil_spec_number: 'PC-E-165', npcil_spec_status: 'Spec Not Issued', drawing_number: '1&2-2358-DD', drawing_status: 'Drawing Not Issued', data_sheet_number: 'Data Sheet', data_sheet_status: 'Drawing Not Issued', as_built_drawing_number: 'As Built', epc_package_name: 'NIMEP', equip_status: 'CCC/STD Released', location: 'Unit 3 - Reactor Building', equipment_type: 'Pump', last_inspection_date: '2024-05-01' },
    { position_id: '6-3221-TK-01', storage_number: 'SN-25478', epc_po_number: 'EPC PO 12345', sub_po_number: 'SUB PO 478', sub_po_vendor: 'SUB PO Vendor', equipment_status_code: 5, npcil_spec_number: 'PC-E-165', npcil_spec_status: 'Spec Issued', drawing_number: '1&2-2358-DD', drawing_status: 'Drawing Issued', data_sheet_number: 'Data Sheet', data_sheet_status: 'Drawing Issued', as_built_drawing_number: 'As Built', epc_package_name: 'NIMEP', equip_status: 'Hydro Tested', location: 'Unit 3 - Tank Farm', equipment_type: 'Tank', last_inspection_date: '2024-05-15' },
  ];

  for (const eq of equipment) {
    const existing = await pool.request()
      .input('pid', sql.NVarChar, eq.position_id)
      .query('SELECT id FROM Equipment WHERE position_id = @pid');
    
    if (existing.recordset.length === 0) {
      await pool.request()
        .input('position_id', sql.NVarChar, eq.position_id)
        .input('storage_number', sql.NVarChar, eq.storage_number)
        .input('epc_po_number', sql.NVarChar, eq.epc_po_number)
        .input('sub_po_number', sql.NVarChar, eq.sub_po_number)
        .input('sub_po_vendor', sql.NVarChar, eq.sub_po_vendor)
        .input('equipment_status_code', sql.Int, eq.equipment_status_code)
        .input('npcil_spec_number', sql.NVarChar, eq.npcil_spec_number)
        .input('npcil_spec_status', sql.NVarChar, eq.npcil_spec_status)
        .input('drawing_number', sql.NVarChar, eq.drawing_number)
        .input('drawing_status', sql.NVarChar, eq.drawing_status)
        .input('data_sheet_number', sql.NVarChar, eq.data_sheet_number)
        .input('data_sheet_status', sql.NVarChar, eq.data_sheet_status)
        .input('as_built_drawing_number', sql.NVarChar, eq.as_built_drawing_number)
        .input('epc_package_name', sql.NVarChar, eq.epc_package_name)
        .input('equip_status', sql.NVarChar, eq.equip_status)
        .input('location', sql.NVarChar, eq.location)
        .input('equipment_type', sql.NVarChar, eq.equipment_type)
        .input('last_inspection_date', sql.Date, eq.last_inspection_date)
        .query(`INSERT INTO Equipment (position_id, storage_number, epc_po_number, sub_po_number, sub_po_vendor, equipment_status_code, npcil_spec_number, npcil_spec_status, drawing_number, drawing_status, data_sheet_number, data_sheet_status, as_built_drawing_number, epc_package_name, equip_status, location, equipment_type, last_inspection_date)
                VALUES (@position_id, @storage_number, @epc_po_number, @sub_po_number, @sub_po_vendor, @equipment_status_code, @npcil_spec_number, @npcil_spec_status, @drawing_number, @drawing_status, @data_sheet_number, @data_sheet_status, @as_built_drawing_number, @epc_package_name, @equip_status, @location, @equipment_type, @last_inspection_date)`);
    }
  }

  console.log('✅ Sample data seeded successfully');
  process.exit(0);
};

seedData().catch(err => { console.error('Seed failed:', err); process.exit(1); });
