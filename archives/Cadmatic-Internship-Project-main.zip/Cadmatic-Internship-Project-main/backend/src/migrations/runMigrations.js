const { sql, getPool } = require('../config/database');

const createTables = async () => {
  const pool = await getPool();

  // Create Equipment table
  await pool.request().query(`
    IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='Equipment' AND xtype='U')
    CREATE TABLE Equipment (
      id INT IDENTITY(1,1) PRIMARY KEY,
      position_id NVARCHAR(50) NOT NULL,
      storage_number NVARCHAR(50),
      epc_po_number NVARCHAR(100),
      sub_po_number NVARCHAR(100),
      sub_po_vendor NVARCHAR(200),
      equipment_status_code INT DEFAULT 0,
      npcil_spec_number NVARCHAR(100),
      npcil_spec_status NVARCHAR(100),
      drawing_number NVARCHAR(100),
      drawing_status NVARCHAR(100),
      data_sheet_number NVARCHAR(100),
      data_sheet_status NVARCHAR(100),
      as_built_drawing_number NVARCHAR(100),
      epc_package_name NVARCHAR(100),
      equip_status NVARCHAR(100),
      location NVARCHAR(200),
      equipment_type NVARCHAR(100),
      last_inspection_date DATE,
      next_inspection_date DATE,
      created_at DATETIME2 DEFAULT GETDATE(),
      updated_at DATETIME2 DEFAULT GETDATE(),
      created_by NVARCHAR(100) DEFAULT 'system',
      is_active BIT DEFAULT 1
    )
  `);

  // Create MaintenanceRecords table
  await pool.request().query(`
    IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='MaintenanceRecords' AND xtype='U')
    CREATE TABLE MaintenanceRecords (
      id INT IDENTITY(1,1) PRIMARY KEY,
      equipment_id INT NOT NULL,
      maintenance_type NVARCHAR(100) NOT NULL,
      description NVARCHAR(MAX),
      performed_by NVARCHAR(200),
      maintenance_date DATETIME2 DEFAULT GETDATE(),
      next_maintenance_date DATE,
      status NVARCHAR(50) DEFAULT 'Completed',
      remarks NVARCHAR(MAX),
      created_at DATETIME2 DEFAULT GETDATE(),
      FOREIGN KEY (equipment_id) REFERENCES Equipment(id)
    )
  `);

  // Create StatusLookup table
  await pool.request().query(`
    IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='StatusLookup' AND xtype='U')
    CREATE TABLE StatusLookup (
      id INT IDENTITY(1,1) PRIMARY KEY,
      status_code INT NOT NULL UNIQUE,
      status_name NVARCHAR(100) NOT NULL,
      status_color NVARCHAR(20),
      description NVARCHAR(200)
    )
  `);

  // Create AuditLog table
  await pool.request().query(`
    IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='AuditLog' AND xtype='U')
    CREATE TABLE AuditLog (
      id INT IDENTITY(1,1) PRIMARY KEY,
      table_name NVARCHAR(100),
      record_id INT,
      action NVARCHAR(20),
      old_value NVARCHAR(MAX),
      new_value NVARCHAR(MAX),
      performed_by NVARCHAR(100),
      performed_at DATETIME2 DEFAULT GETDATE()
    )
  `);

  // Seed StatusLookup
  await pool.request().query(`
    IF NOT EXISTS (SELECT * FROM StatusLookup)
    BEGIN
      INSERT INTO StatusLookup (status_code, status_name, status_color, description) VALUES
      (0, 'Order Not Yet Placed', '#94a3b8', 'Purchase order has not been placed'),
      (1, 'Order Placed', '#3b82f6', 'Purchase order placed with vendor'),
      (2, 'Shipping Release Issued', '#8b5cf6', 'Shipping release has been issued'),
      (3, 'Received at Site', '#f59e0b', 'Equipment received at plant site'),
      (4, 'Erected at Location', '#06b6d4', 'Equipment installed at designated location'),
      (5, 'Hydro Tested', '#10b981', 'Hydraulic testing completed'),
      (6, 'CCC/STD Released', '#84cc16', 'Construction completion certificate released'),
      (7, 'Handover to O&M', '#f97316', 'Equipment handed over to Operations & Maintenance'),
      (8, 'Commissioned', '#22c55e', 'Equipment fully commissioned and operational')
    END
  `);

  console.log('✅ Database tables created/verified successfully');
};

const runMigrations = async () => {
  try {
    await createTables();
    process.exit(0);
  } catch (err) {
    console.error('❌ Migration failed:', err.message);
    process.exit(1);
  }
};

runMigrations();
