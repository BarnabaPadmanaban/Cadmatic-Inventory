const xlsx = require('xlsx');

const statuses = [
  { status_code: 0, status_name: 'Order Not Yet Placed', status_color: '#64748b', description: 'Purchase order has not been placed' },
  { status_code: 1, status_name: 'Order Placed', status_color: '#2563eb', description: 'Purchase order placed with vendor' },
  { status_code: 2, status_name: 'Shipping Release Issued', status_color: '#7c3aed', description: 'Shipping release has been issued' },
  { status_code: 3, status_name: 'Received at Site', status_color: '#c77700', description: 'Equipment received at plant site' },
  { status_code: 4, status_name: 'Erected at Location', status_color: '#008aa0', description: 'Equipment installed at designated location' },
  { status_code: 5, status_name: 'Hydro Tested', status_color: '#05805d', description: 'Hydraulic testing completed' },
  { status_code: 6, status_name: 'CCC/STD Released', status_color: '#5f8f00', description: 'Construction completion certificate released' },
  { status_code: 7, status_name: 'Handover to O&M', status_color: '#ff7700', description: 'Equipment handed over to Operations & Maintenance' },
  { status_code: 8, status_name: 'Commissioned', status_color: '#17833b', description: 'Equipment fully commissioned and operational' },
];

let nextEquipmentId = 9;
let nextMaintenanceId = 1;

const now = () => new Date().toISOString();

const equipment = [
  { id: 1, position_id: '3200-P-01', storage_number: 'SN-25478', epc_po_number: 'EPC PO 12345', sub_po_number: 'SUB PO 478', sub_po_vendor: 'SUB PO Vendor', equipment_status_code: 0, npcil_spec_number: 'PC-E-165', npcil_spec_status: 'Spec Not Issued', drawing_number: '1&2-2358-DD', drawing_status: 'Drawing Issued', data_sheet_number: 'Data Sheet', data_sheet_status: 'Drawing Issued', as_built_drawing_number: 'As Built', epc_package_name: 'NIMEP', equip_status: 'Order Not Yet Placed', location: 'Unit 1 - Pump House', equipment_type: 'Pump', last_inspection_date: '2024-01-15', next_inspection_date: null, created_at: now(), updated_at: now(), is_active: true },
  { id: 2, position_id: '3200-P-02', storage_number: 'SN-25478', epc_po_number: 'EPC PO 12345', sub_po_number: 'SUB PO 478', sub_po_vendor: 'SUB PO Vendor', equipment_status_code: 1, npcil_spec_number: 'PC-E-165', npcil_spec_status: 'Spec Issued', drawing_number: '1&2-2358-DD', drawing_status: 'Drawing Issued', data_sheet_number: 'Data Sheet', data_sheet_status: 'Drawing Issued', as_built_drawing_number: 'As Built', epc_package_name: 'NIMEP', equip_status: 'Order Placed', location: 'Unit 1 - Pump House', equipment_type: 'Pump', last_inspection_date: '2024-02-10', next_inspection_date: null, created_at: now(), updated_at: now(), is_active: true },
  { id: 3, position_id: '3200-P-03', storage_number: 'SN-25478', epc_po_number: 'EPC PO 12345', sub_po_number: 'SUB PO 478', sub_po_vendor: 'SUB PO Vendor', equipment_status_code: 2, npcil_spec_number: 'PC-E-165', npcil_spec_status: 'Spec Not Issued', drawing_number: '1&2-2358-DD', drawing_status: 'Drawing Not Issued', data_sheet_number: 'Data Sheet', data_sheet_status: 'Drawing Not Issued', as_built_drawing_number: 'As Built', epc_package_name: 'NIMEP', equip_status: 'Shipping Release Issued', location: 'Unit 2 - Pump House', equipment_type: 'Pump', last_inspection_date: '2024-03-05', next_inspection_date: null, created_at: now(), updated_at: now(), is_active: true },
  { id: 4, position_id: '3200-P-04', storage_number: 'SN-25478', epc_po_number: 'EPC PO 12345', sub_po_number: 'SUB PO 478', sub_po_vendor: 'SUB PO Vendor', equipment_status_code: 3, npcil_spec_number: 'PC-E-165', npcil_spec_status: 'Spec Issued', drawing_number: '1&2-2358-DD', drawing_status: 'Drawing Not Issued', data_sheet_number: 'Data Sheet', data_sheet_status: 'Drawing Not Issued', as_built_drawing_number: 'As Built', epc_package_name: 'NIMEP', equip_status: 'Received at Site', location: 'Unit 2 - Storage Yard', equipment_type: 'Pump', last_inspection_date: '2024-03-20', next_inspection_date: null, created_at: now(), updated_at: now(), is_active: true },
  { id: 5, position_id: '3200-P-05', storage_number: 'SN-25478', epc_po_number: 'EPC PO 12345', sub_po_number: 'SUB PO 478', sub_po_vendor: 'SUB PO Vendor', equipment_status_code: 8, npcil_spec_number: 'PC-E-165', npcil_spec_status: 'Spec Not Issued', drawing_number: '1&2-2358-DD', drawing_status: 'Drawing Not Issued', data_sheet_number: 'Data Sheet', data_sheet_status: 'Drawing Not Issued', as_built_drawing_number: 'As Built', epc_package_name: 'NIMEP', equip_status: 'Commissioned', location: 'Unit 1 - Control Room', equipment_type: 'Pump', last_inspection_date: '2024-04-12', next_inspection_date: null, created_at: now(), updated_at: now(), is_active: true },
  { id: 6, position_id: '3200-P-06', storage_number: 'SN-25478', epc_po_number: 'EPC PO 12345', sub_po_number: 'SUB PO 478', sub_po_vendor: 'SUB PO Vendor', equipment_status_code: 7, npcil_spec_number: 'PC-E-165', npcil_spec_status: 'Spec Issued', drawing_number: '1&2-2358-DD', drawing_status: 'Drawing Not Issued', data_sheet_number: 'Data Sheet', data_sheet_status: 'Drawing Not Issued', as_built_drawing_number: 'As Built', epc_package_name: 'NIMEP', equip_status: 'Handover to O&M', location: 'Unit 1 - Turbine Hall', equipment_type: 'Pump', last_inspection_date: '2024-04-25', next_inspection_date: null, created_at: now(), updated_at: now(), is_active: true },
  { id: 7, position_id: '6-3221-P-01', storage_number: 'SN-25478', epc_po_number: 'EPC PO 12345', sub_po_number: 'SUB PO 478', sub_po_vendor: 'SUB PO Vendor', equipment_status_code: 6, npcil_spec_number: 'PC-E-165', npcil_spec_status: 'Spec Not Issued', drawing_number: '1&2-2358-DD', drawing_status: 'Drawing Not Issued', data_sheet_number: 'Data Sheet', data_sheet_status: 'Drawing Not Issued', as_built_drawing_number: 'As Built', epc_package_name: 'NIMEP', equip_status: 'CCC/STD Released', location: 'Unit 3 - Reactor Building', equipment_type: 'Pump', last_inspection_date: '2024-05-01', next_inspection_date: null, created_at: now(), updated_at: now(), is_active: true },
  { id: 8, position_id: '6-3221-TK-01', storage_number: 'SN-25478', epc_po_number: 'EPC PO 12345', sub_po_number: 'SUB PO 478', sub_po_vendor: 'SUB PO Vendor', equipment_status_code: 5, npcil_spec_number: 'PC-E-165', npcil_spec_status: 'Spec Issued', drawing_number: '1&2-2358-DD', drawing_status: 'Drawing Issued', data_sheet_number: 'Data Sheet', data_sheet_status: 'Drawing Issued', as_built_drawing_number: 'As Built', epc_package_name: 'NIMEP', equip_status: 'Hydro Tested', location: 'Unit 3 - Tank Farm', equipment_type: 'Tank', last_inspection_date: '2024-05-15', next_inspection_date: null, created_at: now(), updated_at: now(), is_active: true },
];

const maintenance = [];

const statusFor = (code) => statuses.find((status) => status.status_code === Number(code)) || statuses[0];
const activeEquipment = () => equipment.filter((item) => item.is_active);
const withStatus = (item) => ({ ...item, status_name: statusFor(item.equipment_status_code).status_name, status_color: statusFor(item.equipment_status_code).status_color });

const filterEquipment = ({ search, status, package_name, type } = {}) => {
  let rows = activeEquipment();
  if (search) {
    const term = search.toLowerCase();
    rows = rows.filter((item) => [
      item.position_id,
      item.equip_status,
      item.location,
      item.sub_po_vendor,
      item.epc_package_name,
    ].some((value) => String(value || '').toLowerCase().includes(term)));
  }
  if (status !== undefined && status !== '') rows = rows.filter((item) => item.equipment_status_code === Number(status));
  if (package_name) rows = rows.filter((item) => item.epc_package_name === package_name);
  if (type) rows = rows.filter((item) => item.equipment_type === type);
  return rows.sort((a, b) => a.equipment_status_code - b.equipment_status_code || a.position_id.localeCompare(b.position_id));
};

const getAllEquipment = (query) => {
  const page = Number(query.page || 1);
  const limit = Number(query.limit || 50);
  const rows = filterEquipment(query).map(withStatus);
  const offset = (page - 1) * limit;

  return {
    data: rows.slice(offset, offset + limit),
    pagination: { page, limit, total: rows.length, pages: Math.ceil(rows.length / limit) || 1 },
  };
};

const getDashboardStats = () => {
  const rows = activeEquipment();
  const stats = {
    total_equipment: rows.length,
    commissioned: rows.filter((item) => item.equipment_status_code === 8).length,
    handover_om: rows.filter((item) => item.equipment_status_code === 7).length,
    order_not_placed: rows.filter((item) => item.equipment_status_code === 0).length,
    in_progress: rows.filter((item) => item.equipment_status_code >= 1 && item.equipment_status_code <= 4).length,
    testing_phase: rows.filter((item) => [5, 6].includes(item.equipment_status_code)).length,
  };

  const statusBreakdown = statuses.map((status) => ({
    ...status,
    count: rows.filter((item) => item.equipment_status_code === status.status_code).length,
  }));

  const packageBreakdown = Object.values(rows.reduce((acc, item) => {
    if (!item.epc_package_name) return acc;
    acc[item.epc_package_name] ||= { epc_package_name: item.epc_package_name, count: 0 };
    acc[item.epc_package_name].count += 1;
    return acc;
  }, {})).sort((a, b) => b.count - a.count);

  const recentActivity = [...rows]
    .sort((a, b) => new Date(b.updated_at) - new Date(a.updated_at))
    .slice(0, 10)
    .map(({ position_id, equip_status, location, updated_at }) => ({ position_id, equip_status, location, updated_at }));

  return { stats, statusBreakdown, packageBreakdown, recentActivity };
};

const getEquipmentById = (id) => {
  const item = activeEquipment().find((row) => row.id === Number(id));
  if (!item) return null;
  return {
    ...withStatus(item),
    status_description: statusFor(item.equipment_status_code).description,
    maintenance_history: maintenance.filter((row) => row.equipment_id === Number(id)),
  };
};

const createEquipment = (data) => {
  const id = nextEquipmentId++;
  const item = {
    ...data,
    id,
    equipment_status_code: Number(data.equipment_status_code || 0),
    created_at: now(),
    updated_at: now(),
    is_active: true,
  };
  equipment.push(item);
  return id;
};

const updateEquipment = (id, data) => {
  const index = equipment.findIndex((item) => item.id === Number(id) && item.is_active);
  if (index === -1) return false;
  equipment[index] = { ...equipment[index], ...data, equipment_status_code: Number(data.equipment_status_code), updated_at: now() };
  return true;
};

const deleteEquipment = (id) => {
  const item = equipment.find((row) => row.id === Number(id));
  if (!item) return false;
  item.is_active = false;
  item.updated_at = now();
  return true;
};

const addMaintenanceRecord = (equipmentId, data) => {
  const record = {
    id: nextMaintenanceId++,
    equipment_id: Number(equipmentId),
    maintenance_type: data.maintenance_type,
    description: data.description,
    performed_by: data.performed_by,
    maintenance_date: now(),
    next_maintenance_date: data.next_maintenance_date || null,
    status: data.status || 'Completed',
    remarks: data.remarks || null,
    created_at: now(),
  };
  maintenance.push(record);
};

const exportWorkbook = () => {
  const rows = activeEquipment().map((item) => ({
    'Position ID': item.position_id,
    'Storage Number': item.storage_number,
    'EPC PO Number': item.epc_po_number,
    'Sub PO Number': item.sub_po_number,
    Vendor: item.sub_po_vendor,
    Status: statusFor(item.equipment_status_code).status_name,
    'NPCIL Spec': item.npcil_spec_number,
    'Spec Status': item.npcil_spec_status,
    'Drawing No': item.drawing_number,
    'Drawing Status': item.drawing_status,
    'Data Sheet': item.data_sheet_number,
    'Data Sheet Status': item.data_sheet_status,
    Package: item.epc_package_name,
    'Equipment Status': item.equip_status,
    Location: item.location,
    Type: item.equipment_type,
    'Last Inspection': item.last_inspection_date,
    'Last Updated': item.updated_at,
  }));
  const wb = xlsx.utils.book_new();
  const ws = xlsx.utils.json_to_sheet(rows);
  xlsx.utils.book_append_sheet(wb, ws, 'Equipment Status');
  return xlsx.write(wb, { type: 'buffer', bookType: 'xlsx' });
};

module.exports = {
  statuses,
  getAllEquipment,
  getDashboardStats,
  getEquipmentById,
  createEquipment,
  updateEquipment,
  deleteEquipment,
  addMaintenanceRecord,
  exportWorkbook,
};
